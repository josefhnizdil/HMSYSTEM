<?php

include_once 'db_conf.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_errno) {
    printf("Connection error: %s\n", $conn->connect_error);
    exit();
}

if(isset($_POST['floor'])) $floor = $_POST['floor'];
else $floor = 0;

$floors = $conn->query("SELECT * FROM FLOORS WHERE ID='".$floor."'");


$row = mysqli_fetch_array($floors);

$image = $row['IMAGE'];

$myfile = fopen("image", "w+") or die("Unable to open file!");
fwrite($myfile, $image);
fclose($myfile);

list($ancho, $alto, $tipo, $atributos) = getimagesize("image");

$type = exif_imagetype("image");

if(isset($_POST['elements'])){

  for($i=0; $i<=$_POST['elements']; $i++){
      if(!is_numeric($_POST[$i.'x'])) header('Location: #');
      if(!is_numeric($_POST[$i.'y'])) header('Location: #');

      $place = $conn->query("UPDATE PLACES SET X='".$_POST[$i.'x']."', Y='".$_POST[$i.'y']."' WHERE ID='".$_POST[$i.'id']."'");
  }

}

if(isset($_POST['add'])){

  $lasttable = $conn->query("SELECT MAX(CONVERT(ID, UNSIGNED INTEGER)) FROM PLACES");
  $row = mysqli_fetch_array($lasttable);
  $new_table = $row['0']+1;
  //var_dump($row);

  $SQL = "INSERT INTO PLACES (ID,NAME,X,Y,FLOOR) VALUES ('".$new_table."','Table ".$new_table."','50','50','".$_POST['floor']."')";
  $conn->query($SQL);

}

//echo '<img src="data:image/png;base64,',base64_encode($image),'" /><br />'; //Print out each image in the DB  as a base64 encoded string

?>


<!DOCTYPE HTML>
<html>
  <head>
        <!-- A border on the canvas helps us see the edges -->
    <style type="text/css">
      body {  padding-top: 20px; 
        padding-left: 20px; 
        padding-right: 20px; 

      } 
      #container { position: relative; }
      #canvas { border: 1px solid #000; 
        background-image: url('image');
      }
    </style> 
    <script type="text/javascript" src="boxes.js"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="bootstrap-3.3.5-dist/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="bootstrap-3.3.5-dist/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>

  </head>
  <body onLoad="init()">
<div class="row"> 
<div class="col-md-10">
  <canvas id="canvas" <?php echo $atributos; ?>></canvas>
</div>

<div class="col-md-2">

<form action="#" method="post">

<?php


$floors = $conn->query("SELECT * FROM FLOORS");

echo '<select name="floor" onchange="this.form.submit()">';

while ($row = mysqli_fetch_array($floors)){

  echo '<option name="floor" value="'.$row['ID'].'"';
  if($row['ID']==$floor) echo "selected";
  echo '>'.$row['NAME'];
  echo '</option>';

}

echo '</select>';

echo '</form><br>';

echo '<form action="#" method="post">
<input type="hidden" name="floor" value="'.$floor.'">
<input type="hidden" name="add" value="1">
<input type="submit" value="Přidat nový stůl">
</form><br>';

echo '<form action="#" method="post">';

$places = $conn->query("SELECT * FROM PLACES WHERE FLOOR ='".$floor."'");
$i = 0;
while ($row = mysqli_fetch_array($places)){

  echo '<script type="text/javascript">'
     , 'addRect('.$row['X'].', '.$row['Y'].', 130, 100, "#00FFFF");'
     , '</script>'
    ;
  echo '<p class="text-left">'.$row['NAME'].'
    <input type="text" name="'.$i.'x" id="'.$i.'x" value="'.$row['X'].'" size="2" >
    <input type="text" name="'.$i.'y" id="'.$i.'y" value="'.$row['Y'].'" size="2">
    <input type="hidden" name="'.$i.'id" id="'.$i.'y" value="'.$row['ID'].'" size="2">

    </p>';
    $i++;
}
$i--;
echo '<input type="hidden" name="elements" value="'.$i.'">';
echo '<input type="hidden" name="floor" value="'.$floor.'">';

?>

<input type="submit" value="Uložit plán">
</form>
</div>
    <p>Josef Hnízdil</p>
    
</div>
  </body>
</html>   
