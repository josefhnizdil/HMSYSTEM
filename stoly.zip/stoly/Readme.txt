Easy scritp to place tables on UnicentaOPOS v0.1
================================================

What is this?
-------------

This is a litle script writing on PHP5, HTML5, CSS and JavaScript to place tables on 
your UnicentaOPOS install.
This is a beta and you should make a backup of your database and files before use the script.

What do you need?
-----------------

You need the UnicentaOPOS software installed using MySQL database.
Web server with PHP5 support like Apache2

Installation
------------
1º Copy all the files in your web server folder.
2º Edit the dg_conf.php file with your parameters.

	<?php

	//Database configuration file

	$servername = "database_servername";
	$username = "database_username";
	$password = "database_password";
	$database = "database_name";

	?>

3º Enter the URL in your browser (Ej: http://localhost/tables)
4º Enjoy it.

Instructions
------------

Canvas.- Show all the tables and let you move it to any place into the canvas.
Floor selector.- You can select the floor that  you want configure.
Add table.- Add new table into the floor selected.
List of tables.- Swow the list of tables on that floor.
Save.- Save the changes. """""" Very important !!!!! """""" If you don't do it, you will lost all your changes. 

Demo
----

You can see a demo here
http://www.vaniantechnology.com/map

Help
----

If you need some help to use the script or need to improve it, you could contact me at carlosdico@yahoo.es
