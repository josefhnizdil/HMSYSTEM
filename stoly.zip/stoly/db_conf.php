<?php

//Database configuration file

$servername = "localhost:3306";
$username = "root";
$password = "";
$database = "pos";

?>
